import React from 'react'
import FetchData from './Components/FetchData'
import Home from './Components/Home';
import "./index.css"

const App = () => {
    return (
        <div>
            {/* <FetchData/> */}
            <Home/>
        </div>
    )
}

export default App
